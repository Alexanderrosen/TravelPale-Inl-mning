﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Interface;
using TravelPal_2020_10_25_fixed.Managers;

namespace TravelPal_2020_10_25_fixed
{
    /// <summary>
    /// Interaction logic for TravelsWindow.xaml
    /// </summary>
    public partial class TravelsWindow : Window
    {
        List<IUser> users;
        List<Travel> travels;
        Usermanager usermanager;
        Travelmanager travelmanager;
        User user;
        Admin admin;
        Trip trip;
        Travel travel;
        string username;
        string password;
        Vacation vacation;
        TravelDetailsWindow travelDetailsWindow;

        public TravelsWindow(Usermanager usermanager, Travelmanager travelmanager ,string username, string password)
        {

            InitializeComponent();
            this.user = usermanager.Signedinuser as User;
            Admin admin = usermanager.Signedinuser as Admin;
            this.usermanager = usermanager;
            this.travelmanager = travelmanager;

           
            usermanager.GetallUsers(); //Method for returning users
            travelmanager.getTravels(); //Method for returning for travels
            lblUsernameDisplayer.Content = $"Logged in as: {usermanager.Signedinuser.Username}"; //Displays Logged in users username



            if (user is User)
            {
                

                foreach (Travel travel in user.travels) //Gets travels from user
                {
                    ListViewItem item = new();
                    item.Content = travel.Getinfo().ToString(); //Gets info return depending on selected traveltype
                    item.Tag = travel;
                    lvDestinationDisplayer.Items.Add(item); //adds item to listview
                    lvDestinationDisplayer.SelectedItem = btnDetails; // Takes the selected item in the listview and sends it to Detailswindow

                }


                


            }
            else if (admin is Admin) //Gets admin view
            {
                usermanager.GetallUsers();
                travelmanager.getTravels();
                HiddenFeaturesForAdmin();
                foreach (IUser user in usermanager.GetallUsers()) //gets user travel info
                {       

                    if (user is User)
                    {
                        User theuser = (User)user;

                        foreach (Travel travel in theuser.travels) 
                        {
                            ListViewItem item = new();
                            item.Content = $"travel by {user.Username} {travel.GetFullUserInfo()}"; //Sets content to return methods
                            item.Tag = travel;

                            lvDestinationDisplayer.Items.Add(item); //prints who made the travel and the travel info
                        }


                    }


                }
            }



          

        }








    private void btnLogOut_Click(object sender, RoutedEventArgs e) //Log out button that throws the user back to log in screen
        {
            var result = MessageBox.Show("Are you sure you want to log out?", "Information", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if(result == MessageBoxResult.Yes)  //If Yes is pressed user i being logged out from window
            {
                MainWindow mainWindow = new MainWindow(usermanager,travelmanager,username, password);
                mainWindow.Show();
                Close();

            }
            if(result != MessageBoxResult.No) //If no is pressed user continues to be in window
            {

            }

           
            


            
            
        }

        private void btnUser_Click(object sender, RoutedEventArgs e) // If pressed opens userdetailswindow, In userdetailswindow the user can change username, password and country
        {
           
            UserDetailsWindow userDetailsWindow = new(usermanager,travelmanager);
            userDetailsWindow.Show();
            Close();



        }
        private void btnAddTravel_Click(object sender, RoutedEventArgs e) //If pressed opens Addtravelwindow, were the user can add travels
        {
            AddTravel addtravel = new(usermanager,travelmanager,username, password);
            addtravel.Show();
            Close();
        } 

        private void btnDetails_Click(object sender, RoutedEventArgs e)
        {
            if (lvDestinationDisplayer.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select the item with the details you want to view", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning); //If no item is selcted, messagebox popup with instructions.
                return;
            }
            ListViewItem selectedItem = lvDestinationDisplayer.SelectedItem as ListViewItem;
            Travel selectedTravel = selectedItem.Tag as Travel;

            TravelDetailsWindow travelDetailsWindow = new(usermanager, travelmanager, username, password, selectedTravel); //Opens traveldetailswindow with selecteditem info
            travelDetailsWindow.Show();
            Close();
           
        }
        private void btnRemove_Click(object sender, RoutedEventArgs e) //Removes travel when button is pressed and conditions is fullfilled
        {
            List<IUser> users = usermanager.GetallUsers();           
            
            if(lvDestinationDisplayer.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a item to Remove", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ListViewItem selectedItem = lvDestinationDisplayer.SelectedItem as ListViewItem; //sets listviewitem that later on will be the selected item to remove
            Travel selectedTravel = selectedItem.Tag as Travel;
            travelmanager.removeTravel(selectedTravel); 

            foreach(IUser user in users) //searches in user list
            {
                if(user is User)
                {
                    User u = user as User;

                    if(u.travels.Contains(selectedTravel)) //If travel contains selected index travel
                    {
                        u.travels.Remove(selectedTravel); //travel gets removed
                        lvDestinationDisplayer.Items.RemoveAt(lvDestinationDisplayer.SelectedIndex); //clears item from listview
                    }
                }
            }

            
                
        }

        private void btnInformation_Click(object sender, RoutedEventArgs e) // If pressed shows information about the application and the company "Travel Pal"
        {
            MessageBox.Show("Welcome to travelpal!\r\nTravelpal is a travel company established in 2022.\r\nOur maingoal is to make it easier for our clients to plan a trip.\r\nFeatures..\r\nIn the mainscreen we have implemented several options to add/remove trips, See detailed information about your travel and also an option to change current user information.\r\nFound a technial issue? Let us know!\r\n  \r\nBest Regards,\r\nThe team at travelpal!\r\nTravelpal.Contact@Hotmail.com ", "Information", MessageBoxButton.OK, MessageBoxImage.Information);

        }
    
    
    
        
        private void HiddenFeaturesForAdmin() //Hides buttons for Admin except Remove Button to prevent a crash
        {
            
            
                btnAddTravel.Visibility = Visibility.Hidden;
                btnDetails.Visibility = Visibility.Hidden;
                btnInformation.Visibility = Visibility.Hidden;
                btnUser.Visibility = Visibility.Hidden;
            
        }
    
    
    
    }
}
