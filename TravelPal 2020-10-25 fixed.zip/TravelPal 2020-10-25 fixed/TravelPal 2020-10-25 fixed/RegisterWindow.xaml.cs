﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Enums;
using TravelPal_2020_10_25_fixed.Interface;
using TravelPal_2020_10_25_fixed.Managers;

namespace TravelPal_2020_10_25_fixed
{
    /// <summary>
    /// Interaction logic for RegisterWindow.xaml
    /// </summary>
    public partial class RegisterWindow : Window
    {
        Usermanager usermanager;
        Travelmanager travelmanager;

        public RegisterWindow(Usermanager usermanager,Travelmanager travelmanager, string username, string password)
        {
           
            InitializeComponent();

            this.usermanager = usermanager;
            this.travelmanager = travelmanager;
            
            string[] country = Enum.GetNames(typeof(Countries)); //Gets value from enum lsit

            foreach (Countries countrys in Enum.GetValues(typeof(Countries))) //Puts values from enum list in combobox
            {
                cbxCountryselector.Items.Add(countrys);
            }



        }

        

        

        private void Button_Click(object sender, RoutedEventArgs e) //Register Button, Registers username, password and location based on input in textboxes and selected item in combobox and adds to list.
        {

            List<IUser> users = new();
            User user = new();
            user.Username = txtusername.Text;
            user.Password = txtPassword.Text;
          
            
            Countries Location = (Countries)cbxCountryselector.SelectedItem; //Getting country information from user by selected country index
            user.Location = Location;  //sets location for the user

            usermanager.validateUsername(txtusername.Text); //checks if username is already taken.
            this.usermanager.AddUser(user);
            
            Close();

            
        
        
        
        
        
        }

        private void cbxCountryselector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(cbxCountryselector.SelectedItem != null ) // if country is selected btn is enabled
            {
                btnRegister.IsEnabled = true;
            }
        }
    }
}
