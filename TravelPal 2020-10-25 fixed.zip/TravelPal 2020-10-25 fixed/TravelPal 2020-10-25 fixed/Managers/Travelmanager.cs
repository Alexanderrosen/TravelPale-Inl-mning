﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Enums;

namespace TravelPal_2020_10_25_fixed.Managers
{
    public class Travelmanager
    {
        List<Travel> travels = new();
        Usermanager usermanager;
        User user;

        



        public void AddTravel(Vacation vacation)
        {
            travels.Add(vacation);
           
        }
        public void AddTravel(Trip Trip)
        {
            travels.Add(Trip);

        }
        public void removeTravel(Travel travel)
        {
                
            travels.Remove(travel); 
        
        
        
        
        }
        public List<Travel> getTravels()
        { 
            return travels;
           
        }

        
    }
}
