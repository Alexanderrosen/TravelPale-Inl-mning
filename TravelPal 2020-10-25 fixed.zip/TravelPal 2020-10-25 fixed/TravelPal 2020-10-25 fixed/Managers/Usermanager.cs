﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Enums;
using TravelPal_2020_10_25_fixed.Interface;

namespace TravelPal_2020_10_25_fixed.Managers
{
   public class Usermanager 
    {

        Trip trip;
        Travel travel;
        Vacation vacation;


        public string Username { get; set; }
        public string Password { get; set; }
        public Countries Location { get; set; }

        public IUser Signedinuser { get; set; }

        public List<IUser> users = new();

        public Usermanager()
        {
            Admin admin = new Admin() //Adds premade Admin
            {
                Username = "Admin",
                Password = "Password",
            };
            User user = new User() //Adds premade User - Gandalf
            {

                Username = "Gandalf",
                Password = "Password",
                Location = Countries.Cambodia,
                
            };
            Vacation vacation = new(false, "Hammarby", Countries.Sweden, 23);   //Adds trips to user
            Trip Trip = new(Triptypes.Work, "Pizzera Maria", Countries.Bangladesh, 1);

            user.travels.Add(Trip);
            user.travels.Add(vacation);
            users.Add(user);
            users.Add(admin);
            GetallUsers();
        }

        public bool AddUser(IUser user)  //Method for adding user
        {
            users.Add(user);
            return true;
        }

        
        
        public bool validateUsername(string username) //sees if username is already taken
        {  

            User user = new();
           
        
            
            foreach (IUser useer in GetallUsers())
            {
                if (user.Username == username)
                {   

                    MessageBox.Show("Username is already taken. Please choose another username", "Warning", MessageBoxButton.OK, MessageBoxImage.Hand);
                }
               
            }

            return true;

        }
        public List<IUser> GetallUsers() //Returns all users from list
        {
            return users;
        }
       
        

        

        
    }
}
