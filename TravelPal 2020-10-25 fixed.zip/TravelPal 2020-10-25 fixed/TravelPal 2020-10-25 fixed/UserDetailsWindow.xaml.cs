﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Enums;
using TravelPal_2020_10_25_fixed.Interface;
using TravelPal_2020_10_25_fixed.Managers;

namespace TravelPal_2020_10_25_fixed
{
    /// <summary>
    /// Interaction logic for UserDetailsWindow.xaml
    /// </summary>
    
    public partial class UserDetailsWindow : Window
    {
        Travelmanager travelmanager;
        Usermanager Usermanager;
        List<IUser> users;
        User user;
        string username;
        string password;
       
      
        public UserDetailsWindow(Usermanager usermanager,Travelmanager travelmanager)
        {
            InitializeComponent();
            this.Usermanager = usermanager;
            this.travelmanager = travelmanager;
            this.username = usermanager.Signedinuser.Username;
            this.password = usermanager.Signedinuser.Password;



            lblCurrentDisplayer.Content = $"Username: {usermanager.Signedinuser.Username} - Location {usermanager.Signedinuser.Location} ";



            //Puts all the items in Enum Country in the combobox
            foreach (Countries countrys in Enum.GetValues(typeof(Countries)))
            {
                CbxnewCountry.Items.Add(countrys);
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //Save button
        {
            
            // Makes a second password password input checker for later in the if statements to see if the passwords match
            string ComfirmNewpassord = txtConfirmPassword.Text;
            bool isConfirmed = false;
            
            
            //bool that will be true if following conditions is accepted
            if (isConfirmed == false)
            {   //Username cant be shorter then 3 characters
                if (txtNewUsername.Text.Length < 3)
                {

                    Usermanager.validateUsername(txtNewPassword.Text);
                    MessageBox.Show("Username has to contain more than 3 characters.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                //Password cant be shorter then 5 characters
                if (txtNewPassword.Text.Length < 5)
                {   
                    MessageBox.Show("Password must be longer then 5 characters", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                //If the new password is not the same as confirmed password a MessageBox will popup and the user has to rewrite the password for a match
                if (txtNewPassword.Text != txtConfirmPassword.Text)
                {
                    MessageBox.Show("Passwords dont match. Please rewrite your password", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                //If all the conditions is accepted  the changes can be applyied
                if (txtNewUsername.Text.Length >= 3 && txtNewPassword.Text.Length >= 5 && txtNewPassword.Text == txtConfirmPassword.Text)
                {
                    isConfirmed = true;
                   

                }
                

            }
            if(isConfirmed == true)
            {
                this.Usermanager.Signedinuser.Username = txtNewUsername.Text;
                this.Usermanager.Signedinuser.Password = txtNewPassword.Text;
                Countries location = (Countries)CbxnewCountry.SelectedItem;
                this.Usermanager.Signedinuser.Location = location;

                //closes the current window and re-opens Travelswindow
                TravelsWindow travelswindow = new(Usermanager,travelmanager ,username, password ); //Fixa så att Save inte är tillgänglig innan allt är ifyllt
                travelswindow.Show();
                Close();


            }








        }

        private void Button_Click(object sender, RoutedEventArgs e) // Cancel button
        {
           
            TravelsWindow travelsWindow = new(Usermanager, travelmanager, username,password);
            travelsWindow.Show();
            Close();
            
        }

        private void CbxnewCountry_SelectionChanged(object sender, SelectionChangedEventArgs e) //if country index is not selected, save button is disabled 
        {
            if(CbxnewCountry != null)
            {
                btnSave.IsEnabled = true;
            }
        }
    }
}
