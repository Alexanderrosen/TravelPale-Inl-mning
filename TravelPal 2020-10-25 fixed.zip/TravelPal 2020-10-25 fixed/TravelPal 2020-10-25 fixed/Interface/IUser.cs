﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelPal_2020_10_25_fixed.Enums;

namespace TravelPal_2020_10_25_fixed.Interface
{
    public interface IUser //Super class for all users and admin
    {
        public string? Username { get; set; }
        public string? Password { get; set; }

        public Countries Location { get; set; }

    }
}
