﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TravelPal_2020_10_25_fixed;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Enums;
using TravelPal_2020_10_25_fixed.Interface;
using TravelPal_2020_10_25_fixed.Managers;

namespace TravelPal_2020_10_25_fixed
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Travelmanager travelmanager;
        Usermanager usermanager;
        List<IUser> users = new();
        Admin admin;
        User user;
        string username;
        string password;
        public MainWindow()
        {
            InitializeComponent();
            this.usermanager = new();
            this.travelmanager = new();

            foreach(IUser user in this.usermanager.GetallUsers()) //Gets all users
            {
                if(user is User)
                {
                    User u = user as User;

                    foreach(Travel userTravel in u.travels) //search for all travels within the user list
                    {
                        if(userTravel is Trip) //adds travel depending on type of trip
                        {
                            Trip t = userTravel as Trip;
                            this.travelmanager.AddTravel(t);
                        }
                        else if (userTravel is Vacation)
                        {
                            Vacation v = userTravel as Vacation;
                            this.travelmanager.AddTravel(v);
                        }
                    }
                }
            }
        }
        public MainWindow(Usermanager usermanager,Travelmanager travelmanager, string username, string password) //In order to completely close mainwindow and recognize a user, i created a new constructor and send all userinfo to the new mainwindow constructor
        {   
            
            InitializeComponent();
            this.usermanager = usermanager;
            this.travelmanager = travelmanager;
            this.username = username;
            this.password = password;
            usermanager.GetallUsers();

            
        
        
        
        
        
        
        }

        
        private void Button_Click(object sender, RoutedEventArgs e) // Log in button
        {
            users = usermanager.GetallUsers();

            string username = txtusername.Text; 
            string password = txtpassword.Password;
           
            bool isFoundUser = false;
            
            //Checks the user list to see if inputs matches from register window
            foreach (IUser user in users)
            {
               

                if (user.Username == username && user.Password == password)
                {
                    isFoundUser = true;
                    usermanager.Signedinuser = user;
                    TravelsWindow travelsWindow = new(usermanager,travelmanager,username,password);
                    travelsWindow.Show();
                    Close();

                    


                }
                
                






            }

            if (!isFoundUser) //if user is not found a messagebox will show with further instructions
            {
                MessageBox.Show("Wrong username or password. Please try again or register", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            


        }



        private void Register_Click(object sender, RoutedEventArgs e) //Register button that opens register window
        {
            RegisterWindow registerWindow = new RegisterWindow(usermanager,travelmanager,username,password);
            registerWindow.Show();



        }




    }
}
