﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelPal_2020_10_25_fixed.Enums;
using TravelPal_2020_10_25_fixed.Interface;

namespace TravelPal_2020_10_25_fixed.Classes
{
    internal class Admin : IUser
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
        public Countries Location { get; set ; }
    
    
    
        
    
    }
}
