﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelPal_2020_10_25_fixed.Enums;

namespace TravelPal_2020_10_25_fixed.Classes
{
    public class Vacation : Travel
    {
        User user;

        
        public bool Allinclusive { get; set; }

        public Vacation(bool allinclusive,string destination, Countries country, int travelers) : base(destination, country, travelers)
        {
            
            Allinclusive = allinclusive;

        }
       

        public override string Getinfo() 
        {
            return $"Destination {Destination.ToString()} in {Country.ToString()}";
        }
        public override string GetTravelInfo()
        {
            return $"AllInclusive: {Allinclusive.ToString()}";
        }

        public override string GetTypeOfTravelInfo()
        {
            return $"TravelType: {TravelType.Vaccation.ToString()}";
        }
        public override string GetFullUserInfo()
        {
            return $" Destination: {Destination} - Country:{Country.ToString()} - Travellers{Travelers.ToString()} Type of Travel: {TravelType.Vaccation.ToString()} AllInclusive: {Allinclusive.ToString()}";
        }
        public override string GetCountry()
        {
            return $"Country: {Country.ToString()}";
        }
        public override string GetDestination()
        {
            return $"Destination: {Destination.ToString()}" ;
        }
        public override string GetPassangers()
        {
            return $"Travelers: {Travelers.ToString()} ";
        }






    }   
}
