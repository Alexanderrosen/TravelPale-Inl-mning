﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelPal_2020_10_25_fixed.Enums;
using TravelPal_2020_10_25_fixed.Interface;

namespace TravelPal_2020_10_25_fixed.Classes
{
    public class Trip : Travel
    {
        Admin admin;

        public Triptypes Type { get; set; }
        public Trip(Triptypes type, string destination, Countries country, int travelers) : base(destination, country, travelers)
        {
            Type = type;


        }


        User user;

        public override string Getinfo()
        {
            return $"Destination {Destination.ToString()} in {Country.ToString()}";
        }
        public override string GetTravelInfo()
        {
            return $"TripType: {Type.ToString()}";
        }
        public override string GetTypeOfTravelInfo()
        {
            return $"Traveltype: {TravelType.Trip.ToString()}";
        }
        public override string GetFullUserInfo()
        {
            return $"Destination: {Destination} - Country: {Country.ToString()} - Travellers: {Travelers.ToString()} TravelType: {TravelType.Trip.ToString()} TripType {Type.ToString()}";
        }
        public override string GetCountry()
        {
            return $"Country: {Country.ToString()}";
        }
        public override string GetDestination()
        {
            return $"Destination: {Destination.ToString()}";
        }
        public override string GetPassangers()
        {
            return $"Travelers: {Travelers.ToString()} ";
        }
    }
}