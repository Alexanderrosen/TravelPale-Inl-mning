﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using TravelPal_2020_10_25_fixed.Enums;

namespace TravelPal_2020_10_25_fixed.Classes
{
    public class Travel
    {

        public string Destination { get; set; }

        public Countries Country { get; set; }

        public  int Travelers { get; set; }

       

       public Travel(string destination, Countries country, int travelers)
       {
            Destination = destination;
            Country = country;
            Travelers = travelers;  

            
            
       }
       public virtual string Getinfo()
        {
            return "";
        }
        public virtual string GetTravelInfo()
        {
            return "";
        }
        public virtual string GetTypeOfTravelInfo()
        {
            return $"";
        }
        public virtual string GetFullUserInfo()
        {
            return "";
        }
        public virtual string GetPassangers()
        {
            return "";
        }
        public virtual string GetDestination()
        {
            return "";

        }
        public virtual string GetCountry()
        {
            return "";
        }
       
      



    }



}
