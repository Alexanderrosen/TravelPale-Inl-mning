﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Enums;
using TravelPal_2020_10_25_fixed.Interface;
using TravelPal_2020_10_25_fixed.Managers;

namespace TravelPal_2020_10_25_fixed
{
    /// <summary>
    /// Interaction logic for AddTravel.xaml
    /// </summary>
    public partial class AddTravel : Window
    {
        Usermanager usermanager;
        List<Travel> travels = new();
        Travelmanager travelmanager;
        Travel travel;
        Trip trip;
        Vacation vacation;
        User user;
        
        
        string username;
        string password;
        public AddTravel(Usermanager usermanager, Travelmanager travelmanager, string usernamem, string password)
        {
            InitializeComponent();

            this.travelmanager = travelmanager;
            this.usermanager = usermanager;

            string[] country = Enum.GetNames(typeof(Countries));
            foreach(Countries countries in Enum.GetValues(typeof(Countries))) //Loads comboboxes with values
            {
                cbxGoToCountry.Items.Add(countries);
            }
            
            string[]type = Enum.GetNames(typeof(TravelType));
            
            foreach(TravelType trippie in Enum.GetValues(typeof(TravelType))) //Loads comboboxes with values
            {
                cbxTripOrVac.Items.Add(trippie);
               
            }



        }

        private void btnAddTrip_Click(object sender, RoutedEventArgs e)
        {
            
            try //Trys the metod
            {
                string destination = txtDestination.Text;
                Countries country = (Countries)cbxGoToCountry.SelectedItem;
                int travlers = Convert.ToInt32(txtPassengers.Text);

                if (cbxTripOrVac.SelectedIndex == 0)
                {



                    Triptypes triptype = (Triptypes)cbxTripType.SelectedItem;


                    trip = new(triptype, destination, country, travlers); //Adds inputs to values 

                    this.travelmanager.AddTravel(trip);

                    User user = usermanager.Signedinuser as User;
                    user.travels.Add(trip);

                }
                if (cbxTripOrVac.SelectedIndex == 1)
                {



                    bool allinclusive = (bool)CkbxAllInclusive.IsChecked;
                    vacation = new(allinclusive, destination, country, travlers); //Adds inputs to values 

                    this.travelmanager.AddTravel(vacation);
                    User user = usermanager.Signedinuser as User; //adds local trip to local user
                    user.travels.Add(vacation); //adds travel to list with travels


                }
            }

            catch (Exception ex) //catches exception if int travelers was a string
            {
                MessageBox.Show("Travelers was not in correct format. You will now be send to homewindow.");
            }
            
                TravelsWindow travelsWindow = new(usermanager, travelmanager, username, password); //Closes current window and takes user back to TravelsWindow
                travelsWindow.Show();
                Close();



         
            


        }

        private void cbxTripOrVac_SelectionChanged(object sender, SelectionChangedEventArgs e) 
        {
            if(cbxTripOrVac.SelectedIndex == (int)TravelType.Vaccation)//If selected Item == Vacction(Show Combobox and label)
            {  //Changing visability to visible
                CkbxAllInclusive.Visibility = Visibility.Visible;
                lblAllInlusive.Visibility = Visibility.Visible;
                //Changing visability to hidden
                cbxTripType.Visibility = Visibility.Hidden;
                lblTriptype.Visibility = Visibility.Hidden;
            }   
            if(cbxTripOrVac.SelectedIndex == (int)TravelType.Trip)  //if selected item == Trip(Show Allinclusive and label)
            {    
                //Changing visability to hidden 
                CkbxAllInclusive.Visibility = Visibility.Hidden;
                lblAllInlusive.Visibility = Visibility.Hidden;

                //Changing visability to visible
                cbxTripType.Visibility = Visibility.Visible;
                lblTriptype.Visibility = Visibility.Visible;
                string[]LeisureWork = Enum.GetNames(typeof(Triptypes));
                //Adds TripTypes in Combobox if selected item == Trip
               
                foreach(Triptypes triptype in Enum.GetValues(typeof(Triptypes))) //Adds triptypes to hidden combobox
                {
                    cbxTripType.Items.Add(triptype);
                }

              

               
                
            }

           
            if(cbxGoToCountry.SelectedIndex != null && cbxTripOrVac.SelectedIndex == 1) //if index is not selected btn is disabled
            {
                if (true)
                {
                    btnAddTrip.IsEnabled = true;
                }
          
            }
            if(cbxTripOrVac.SelectedIndex != 1 && cbxTripType.SelectedIndex != null) //if index is not selected btn is disabled
            {
                if (true)
                {
                    btnAddTrip.IsEnabled = true;
                }
            }
           


        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            TravelsWindow travelswindow = new(usermanager, travelmanager, username, password); //Takes user back to Travelwindow
            travelswindow.Show();
            Close();
        }
    }
}
