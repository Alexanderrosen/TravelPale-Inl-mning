﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelPal_2020_10_25_fixed.Enums
{
    public enum TravelType //Enum with Traveltypes for comboboxes
    {
        Trip,
        Vaccation,


    }
}
