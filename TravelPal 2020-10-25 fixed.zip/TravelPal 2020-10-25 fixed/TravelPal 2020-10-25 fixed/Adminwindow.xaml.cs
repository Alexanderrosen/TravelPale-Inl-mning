﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Interface;
using TravelPal_2020_10_25_fixed.Managers;

namespace TravelPal_2020_10_25_fixed
{
    /// <summary>
    /// Interaction logic for Adminwindow.xaml
    /// </summary>
    /// 



    public partial class Adminwindow : Window
    {

        List<IUser> users;
        List<Travel> travels;
        Usermanager usermanager;
        Travelmanager travelmanager;
        User user;
        Admin admin;
        Trip trip;
        Travel travel;
        string username;
        string password;
        
       


        public Adminwindow(Usermanager usermanager, Travelmanager travelmanager, string username, string password)
        {
            InitializeComponent();
            this.usermanager = usermanager;
            this.travelmanager = travelmanager;
            this.username = username;
            this.password = password;





            lvtripdisplayer.Items.Clear();

            usermanager.GetallUsers();
            usermanager.GetallUsers();
            travelmanager.getTravels();
            

            
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {

            travelmanager.getTravels();

            ListViewItem selecteditem = lvtripdisplayer.SelectedItem as ListViewItem;
            Travel selectedTravel = selecteditem.Tag as Travel;
            travelmanager.removeTravel(selectedTravel);
            foreach(User user in usermanager.GetallUsers())
            {
                if(selecteditem.Tag is User)
                {
                    travels.Remove(selectedTravel);
                }
            }

            
            



        }
    
    
    
    
    
    
}   } 
