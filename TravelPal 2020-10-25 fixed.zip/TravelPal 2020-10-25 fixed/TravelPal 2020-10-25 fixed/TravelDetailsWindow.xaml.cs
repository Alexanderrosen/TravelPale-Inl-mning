﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelPal_2020_10_25_fixed.Classes;
using TravelPal_2020_10_25_fixed.Enums;
using TravelPal_2020_10_25_fixed.Managers;

namespace TravelPal_2020_10_25_fixed
{
    /// <summary>
    /// Interaction logic for TravelDetailsWindow.xaml
    /// </summary>
    public partial class TravelDetailsWindow : Window
    {
        Usermanager usermanager;
        Travelmanager travelmanager;
        string username;
        string password;
        Travel travel;
        Trip trip;
        Vacation vacation;
        User user;
        Triptypes triptypes;
        TravelType traveltype;
        private Travel? selectedTravel;

        public TravelDetailsWindow(Usermanager usermanager,Travelmanager travelmanager,string username, string password, Travel selectedTravel)
        {


            InitializeComponent();
            this.usermanager = usermanager;             
            this.travelmanager = travelmanager;
            this.username = username;
            this.selectedTravel = selectedTravel;
            this.password = password;
            User user = usermanager.Signedinuser as User;
            LoadBoxex();
           
            







        }

       

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {

            TravelsWindow travelsWindow = new(usermanager,travelmanager,username,password); //Closes current window and opens Travelswindow
            travelsWindow.Show();
            clearUi();
            Close();



        }
        private void LoadBoxex()
        {
            txtDestination.Text = selectedTravel.GetDestination();  //Sets values in textboxes based on travel inputs in addtravel window
            txtCountry.Text = selectedTravel.GetCountry();
            txtPassangers.Text = selectedTravel.GetPassangers();
            txtvacortrip.Text = selectedTravel.GetTypeOfTravelInfo().ToString();
            txtallincOrTripType.Text = selectedTravel.GetTravelInfo().ToString();
        }
        private void clearUi()
        {
            txtDestination.Clear(); // Clears textboxes
            txtPassangers.Clear();
            txtCountry.Clear();
            txtallincOrTripType.Clear();
            txtvacortrip.Clear();
        }

    }
}
